
def channel_config():
    json_config = {
        "group": "",
        # "frameworks": [
        #     #热云的库文件
        #     "Security.framework",
        #     "CoreTelephony.framework",
        #     "AdSupport.framework",
        #     "SystemConfiguration.framework",
        #     "CoreMotion.framework",
        #     "iAd.framework",
        #     'AdServices.framework',
        #     'AVFoundation.framework',
        #     "CFNetwork.framework",
        #     'WebKit.framework'
        #     #热云结束
        # ],
        # "libs": [
        #     "libsqlite3.tbd",
        #     "libz.tbd",
        #     "libresolv.tbd"
        # ],
        # 动态库列表
        "DynamicFrameworks": [
            "yqhySDK.framework"
        ],
        'privicy':{
            "NSPhotoLibraryAddUsageDescription":"App使用您的相册功能来保存账号密码，需要您的同意",
            'NSPhotoLibraryUsageDescription':"App使用您的相册功能来保存账号密码，需要您的同意",
            "Camera Usage Description":"App使用您的相册功能来保存账号密码，需要您的同意",
            "Microphone Usage Description":"App使用您的麦克风来完成发送语音信息，需要您的同意",
        },
        'DCSDK': {
            'AppId': "10944",
            'AppKey': '9b09a29feb37ca4aed0bdfc463194f98',
            'DCUrl': 'http://api.gamedachen.com',
            'appSecret': 'e48d350cec9c60fa0cf3b3d64f2bb44f',
            'Channel': '12079',
            'sdkId': '102',
            'Plugins': [
                {
                    "appid":"5048",
                    'appkey':"8f3f6a4367662065fdc4c45ab1bebabf",
                    "name":"277"
                }
            ]
        },
        'LSApplicationQueriesSchemes': [
            'alipay',
            'qyhysyt1',
            'qyhysyt2',
            'qyhysyt3',
            'qyhysyt4',
            'qyhysyt5',
            'qyhysyt6',
            'qyhysyt7',
            'qyhysyt8',
            'qyhysyt9',
            'qyhysyt10'
        ],
        'CFBundleURLTypes':[
            {
                'CFBundleTypeRole':"Editor",
                'CFBundleURLSchemes':[
                    "$(PRODUCT_BUNDLE_IDENTIFIER).277"
                ]
            }
        ]
    }
    # $(PRODUCT_BUNDLE_IDENTIFIER)
    #合规证明
    # < key > ITSAppUsesNonExemptEncryption < / key > < false / >

    return json_config