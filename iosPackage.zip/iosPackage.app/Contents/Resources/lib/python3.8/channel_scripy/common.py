import os
import plistlib
from pbxproj import XcodeProject
# from mod_pbxproj import XcodeProject
import subprocess

from package_ui.LogUtils import *

# from pbxproj import XcodeProject


copyFileCounts = 0
plugins_channel = {}

def channel_config():
    json_config = {
        "group": "",
        "setting" : {

            "Preprocessor Macros": [
                "HAVE_CONFIG_H"
            ],
            'otherlinker': [
                '-ObjC',
                '-lsqlite3.0'
            ]
        },
        # "frameworks": [
        #     #热云的库文件
        #     "Security.framework",
        #     "CoreTelephony.framework",
        #     "AdSupport.framework",
        #     "SystemConfiguration.framework",
        #     "CoreMotion.framework",
        #     "iAd.framework",
        #     'AdServices.framework',
        #     'AVFoundation.framework',
        #     "CFNetwork.framework",
        #     'WebKit.framework'
        #     #热云结束
        # ],
        # "libs": [
        #     "libsqlite3.tbd",
        #     "libz.tbd",
        #     "libresolv.tbd"
        # ],
        'privicy':{
            "NSPhotoLibraryAddUsageDescription":"App使用您的相册功能来保存账号密码，需要您的同意",
            'NSPhotoLibraryUsageDescription':"App使用您的相册功能来保存账号密码，需要您的同意",
            "Camera Usage Description":"App使用您的相册功能来保存账号密码，需要您的同意",
            "Microphone Usage Description":"App使用您的麦克风来完成发送语音信息，需要您的同意",
            "NSUserTrackingUsageDescription":"App使用您的广告追踪功能来实现活动消息的推送，需要您的同意"
        },
        'DCSDK':{
            'AppId':"",
            'AppKey':'',
            'Channel':'',
            'DCUrl':'',
            'appSecret':'',
            'sdkId':'',
            'Plugins': [
                {
                    "productKey": "b618cc3dca1e4272b50a804686b45f55",
                    "name": "lianyun_old",
                    "channelId": "3",
                    "productId": "2633",
                    "rootServer": ""
                }
            ]
        },
        'LSApplicationQueriesSchemes': [
            'mqq'
        ],
        'CFBundleURLTypes':[
            {
                'CFBundleTypeRole':"Editor",
                'CFBundleURLSchemes':[
                    "$(PRODUCT_BUNDLE_IDENTIFIER)"
                ]
            }
        ]
    }
    # $(PRODUCT_BUNDLE_IDENTIFIER)
    #合规证明
    # < key > ITSAppUsesNonExemptEncryption < / key > < false / >
    return json_config

def copyFiles(sourceDir, targetDir):
 global copyFileCounts
 #print (u"%s 当前处理文件夹%s已处理%s 个文件" %(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())), sourceDir,copyFileCounts))
 for f in os.listdir(sourceDir):
  sourceF = os.path.join(sourceDir, f)
  targetF = os.path.join(targetDir, f)
  if os.path.isfile(sourceF):
   #创建目录
   if not os.path.exists(targetDir):
    os.makedirs(targetDir)
   copyFileCounts += 1
   #文件不存在，或者存在但是大小不同，覆盖
   if not os.path.exists(targetF) or (os.path.exists(targetF) and (os.path.getsize(targetF) != os.path.getsize(sourceF))):
    #2进制文件
    open(targetF, "wb").write(open(sourceF, "rb").read())
    #print (u"%s %s 复制完毕" %(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())), targetF))
   else:
    #print (u"%s %s 已存在，不重复复制" %(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())), targetF))
     pass
  if os.path.isdir(sourceF):
   copyFiles(sourceF, targetF)

#将渠道资源复制到target工程--添加渠道资源
def handel_channel_libsAndResource(xcode_proj_path,target,plist_path,channel_resource,channle_id):
    logger = LogUtils.sharedInstance(channle_id)
    print('xcode' + xcode_proj_path)

    logger.info('开始拷贝渠道资源')

    # 将渠道资源文件拷贝到plist文件同级目录
    # parent_plist_parth = os.path.dirname(plist_path)
    # targetResource = parent_plist_parth + "/" + channel_resource

    #将渠道资源文件拷贝到xcode文件同级目录
    parent_plist_parth = os.path.dirname(xcode_proj_path)
    targetResource = parent_plist_parth + "/" + channel_resource

    current_working_dir = os.getcwd()
    sdkReource_path   =  "channels/" + channel_resource
    sdkReource_path   = os.path.join(current_working_dir, sdkReource_path)

    copyFiles(sdkReource_path,targetResource)
    print("渠道文件路径：" + targetResource)

    logger.info('拷贝渠道资源  done')

    #复制完文件之后 处理渠道plist文件参数

    return  targetResource

    # xcode_proj_path = os.path.join(xcode_proj_path, "project.pbxproj")
    # my_project = XcodeProject.load(xcode_proj_path)
    # # my_project.get_or_create_group('dcLianyun_old')
    # # file_options = FileOptions(weak=True)
    #
    # for parent, folders, files in os.walk(targetResource):
    #     for folder in folders:
    #         if folder.endswith(".bundle") | folder.endswith(".framework"):
    #             folderpath = os.path.join(parent, folder)
    #             if parent.find(".framework") == -1:
    #                 print("folderpath :" + folderpath)
    #                 my_project.add_file(path=folderpath)
    #
    #             # elif parent.find(".bundle") != -1:
    #             #     print("folderpath :" + folderpath)
    #             #     # my_project.add_file(path=folderpath)
    #
    #     for file in files:
    #         if  file.endswith(".png") | file.endswith(".jpg") | file.endswith(".plist"):
    #             filepath = os.path.join(parent, file)
    #             if filepath.find(".bundle") == -1 & filepath.find(".framework") == -1:
    #                 print("filepath :" + filepath)
    #                 my_project.add_file(path=filepath)
    #         elif file.endswith(".a"):
    #             filepath = os.path.join(parent, file)
    #             print("filepath :" + filepath)
    #             my_project.add_file(path=filepath)
    #
    # # my_project.add_folder(path=targetResource)
    # # my_project.add_file(path=targetResource)
    # my_project.save(xcode_proj_path)
    #
    # print("-----渠道工程生成完毕------")
    # return 1

    # current_working_dir = os.getcwd()
    # rb_path = 'modifyPrj/interface/addEntitlements.rb'
    # rb_path = os.path.join(current_working_dir, rb_path)
    # cmd = "ruby " + rb_path + " " + xcode_proj_path + " " + target + " " + rb_path
    # p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    # # res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    # output, errors = p.communicate()
    # if errors == None:
    #     print("-- 添加渠道文件-done---")
    #     print(output)
    # else:
    #     print("-- ruby 脚本 运行错误 ---")

#添加系统库
def handel_libs(xcode_proj_path,targetName,plistConfig,channel_id):
    logger = LogUtils.sharedInstance(channel_id)
    logger.info('工程路径:' + xcode_proj_path)
    print('工程路径:' + xcode_proj_path)
    target = targetName
    lib_arr = []
    change_plist_content = plistConfig

    isAdServicesExist = 0

    if ("frameworks" in change_plist_content.keys()):
        for v in change_plist_content['libs']:
            lib_arr.append(v)

    if ("libs" in change_plist_content.keys()):
        for v in change_plist_content['frameworks']:
            if v == "AdServices.framework":
                isAdServicesExist = 1
            lib_arr.append(v)

    lib_str = ''
    for i in range(len(lib_arr)):
        if i == len(lib_arr) - 1:
            lib_str = lib_str + lib_arr[i]
        else:
            lib_str = lib_str + lib_arr[i] + ','

    #获取当前工作路径
    current_working_dir = os.getcwd()
    rb_path = 'modifyPrj/interface/addSystemFrameworks.rb'
    rb_path = os.path.join(current_working_dir,rb_path)
    print(lib_str)

    cmd = "ruby " + rb_path +" " + xcode_proj_path + " "  + target + " " + lib_str
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    # res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output, errors = p.communicate()
    if errors == None:
        print("-- 添加系统库 -done---")
        print(output)
        logger.info('添加系统库 -done---')
    else:
        print("-- ruby 脚本 运行错误 ---")


    # 添加系统库之后，假如 有 AdServices.framework ，iOS 10 7会闪退，额外添加弱引用
    if isAdServicesExist == 1:
        old_text = 'AdServices.framework */;'
        new_text = 'AdServices.framework */; settings = {ATTRIBUTES = (Weak, ); };'
        judgeStr = "AdServices.framework */; settings"
        if selStr(old_text,judgeStr) == -1:
            pb_path = xcode_proj_path + "/project.pbxproj"
            replaceStringInFile(pb_path, old_text, new_text)
    logger.info(output)


# 查询
def selStr(rootStr,searchStr):
    nPos2 = rootStr.find(searchStr)
    return nPos2

def replaceStringInFile(full_path, old_text, new_text):
    with open(full_path, "r",encoding='utf-8', errors='ignore') as fileObj:
        all_text = fileObj.read()
        fileObj.close()

    all_text = all_text.replace(old_text, new_text)
    with open(full_path, "w",encoding='utf-8', errors='ignore') as fileObj:
        fileObj.write(all_text)
        fileObj.close()
def handel_plist(plist_path,plistConfig,curent_chose_channel_id):
    logger = LogUtils.sharedInstance(curent_chose_channel_id)
    logger.info(u'开始处理渠道参数')

    global plugins_channel
    change_plist_content = plistConfig
    privicy = plistConfig['privicy']
    channel_param = plistConfig['DCSDK']
    url_type = plistConfig['CFBundleURLTypes']

    #幻夜渠道===特殊处理数据源
    if curent_chose_channel_id == '24' or curent_chose_channel_id == '23' or curent_chose_channel_id == '13'\
            or curent_chose_channel_id == '20' or curent_chose_channel_id == '19':
        WANCMS_GAMEID =  channel_param['Plugins'][0]['WANCMS_GAMEID']
        value = url_type[1]['CFBundleURLSchemes'][0]
        url_type[1]['CFBundleURLSchemes'][0] = value + str(WANCMS_GAMEID)
    if  curent_chose_channel_id == '9':
        WANCMS_GAMEID = channel_param['Plugins'][0]['MAIY_GAMEID']
        value = url_type[1]['CFBundleURLSchemes'][0]
        url_type[1]['CFBundleURLSchemes'][0] = value + str(WANCMS_GAMEID)


    find_key = 'DCSDK'
    if os.path.isfile(plist_path):
        with open(plist_path, 'rb') as fp:
            plist = plistlib.load(fp, fmt=None, dict_type=dict)
            if len(privicy) >0:
               for k in privicy:
                   plist[k] = privicy[k]
            else:
                print("----请先接入--聚合SDK")
                exit(0)
            plist[find_key]  = channel_param
            #xiaoqi -小七渠道额外添加横竖屏 判断
            plugins_channel = plist[find_key]['Plugins'][0]
            if plugins_channel.keys().__contains__('SMScreenMode'):
                plist['SMScreenMode'] = plugins_channel['SMScreenMode']
            if plist.keys().__contains__('CFBundleURLTypes'):
                temp = []
                for k in plist['CFBundleURLTypes']:
                    temp.append(k)
                for value in url_type:
                    temp.append(value)
                plist['CFBundleURLTypes'] = temp
            else:
                plist['CFBundleURLTypes'] = url_type

        #添加白名单
            if plistConfig.keys().__contains__('LSApplicationQueriesSchemes'):
                schemes = plistConfig['LSApplicationQueriesSchemes']
                if plist.keys().__contains__('LSApplicationQueriesSchemes'):
                    temp = []
                    for k in plist['LSApplicationQueriesSchemes']:
                        temp.append(k)
                    for value in schemes:
                        temp.append(value)
                    plist['LSApplicationQueriesSchemes'] = temp
                else:
                    plist['LSApplicationQueriesSchemes'] = schemes
        with open(plist_path, 'wb') as fp:
            # sort_keys 是否排序
            plistlib.dump(value=plist, fp=fp, fmt=plistlib.FMT_XML, sort_keys=True, skipkeys=False)

    logger.info(u'渠道参数配置完成')
    #-----只替换plugin的处理方式
    # if os.path.isfile(plist_path):
    #
    #     with open(plist_path, 'rb') as fp:
    #         plist = plistlib.load(fp, fmt=None, dict_type=dict)
    #         if len(privicy) >0:
    #            for k in privicy:
    #                plist[k] = privicy[k]
    #         plist[find_key]['Plugins']  = plugins
    #         if plist.keys().__contains__('CFBundleURLTypes'):
    #             temp = []
    #             for k in plist['CFBundleURLTypes']:
    #                 temp.append(k)
    #             temp.append(url_type[0])
    #             plist['CFBundleURLTypes'] = temp
    #         else:
    #             plist['CFBundleURLTypes'] = url_type
    #
    #     with open(plist_path, 'wb') as fp:
    #         # sort_keys 是否排序
    #         plistlib.dump(value=plist, fp=fp, fmt=plistlib.FMT_XML, sort_keys=True, skipkeys=False)
        # print(plist)


#使用ruby  添加---渠道资源--动态库
def handel_DynamicFrameworks(xcode_proj_path,targetName,frameworks,frameworks_path,groupName,search_path,channel_id):
    logger = LogUtils.sharedInstance(channel_id)
    print('工程路径:' + xcode_proj_path)
    target = targetName
    # lib_arr = []
    # change_plist_content = plistConfig
    # for v in change_plist_content['libs']:
    #     lib_arr.append(v)
    #
    # for v in change_plist_content['frameworks']:
    #     lib_arr.append(v)
    #
    # lib_str = ''
    # for i in range(len(lib_arr)):
    #     if i == len(lib_arr) - 1:
    #         lib_str = lib_str + lib_arr[i]
    #     else:
    #         lib_str = lib_str + lib_arr[i] + ','

    current_working_dir = os.getcwd()
    rb_path = 'modifyPrj/interface/addDynamicFrameworks.rb'
    rb_path = os.path.join(current_working_dir,rb_path)
    print("------动态库列表------")
    print(frameworks)

    lib_arr = []

    for v in frameworks:
        lib_arr.append(v)

    lib_str = ''
    for i in range(len(lib_arr)):
        if i == len(lib_arr) - 1:
            lib_str = lib_str + lib_arr[i]
        else:
            lib_str = lib_str + lib_arr[i] + ','

    #动态库固定文件夹名称 DynamicFrameworks
    dframework_path = os.path.join(current_working_dir,frameworks_path)
    print("------动态库路径------")
    print(dframework_path)


    cmd = "ruby " + rb_path +" " + xcode_proj_path + " "  + target + " " + lib_str + " " + dframework_path + " " + groupName + " " + search_path
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    # res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output, errors = p.communicate()
    if errors == None:
        print("-- 添加动态库 -done---")
        print(output)
    else:
        print("-- ruby 脚本 运行错误 ---")

    logger.info('添加动态库 -done---')
    logger.info(output)

#添加渠道-非动态库资源,真实路径 channel_resource  channel_resource_name--渠道资源 跟目录
def add_channel_resource(xcode_proj_path,target,channel_resource,channel_resource_name,other_linker_str,channel_id):
    logger = LogUtils.sharedInstance(channel_id)
    print('xcode' + xcode_proj_path)

    print("渠道文件路径：" + channel_resource)

    sub_path = os.path.abspath(os.path.dirname(xcode_proj_path))
    # print("--sub " + sub_path)
    sub_path = sub_path + "/"
    # print("=====sub_path - 长度 " + str(len(sub_path)))

    lib_arr = []
    for parent, folders, files in os.walk(channel_resource):
        for folder in folders:
            if folder.endswith(".bundle") | folder.endswith(".framework"):
                folderpath = os.path.join(parent, folder)
                if parent.find(".framework") == -1 & parent.find("DynamicFrameworks") == -1 & parent.find(".bundle") == -1 :
                    # print("folderpath :" + folderpath)

                    save_path = folderpath[len(sub_path):]
                    # print(" save_folder_path---" +  save_path)
                    lib_arr.append(save_path)

                # elif parent.find(".bundle") != -1:
                #     print("folderpath :" + folderpath)
                #     # my_project.add_file(path=folderpath)

        for file in files:
            if  file.endswith(".png") | file.endswith(".jpg") | file.endswith(".plist") | file.endswith(".nib") | file.endswith(".h") | file.endswith(".m") | file.endswith(".mm") | file.endswith(".c") | file.endswith(".TTF"):
                filepath = os.path.join(parent, file)
                if filepath.find(".bundle") == -1 & filepath.find(".framework") == -1 & filepath.find("DynamicFrameworks") == -1:
                    # print("filepath :" + filepath)
                    save_path = filepath[len(sub_path):]
                    # print(" save_file_path---" + save_path)
                    lib_arr.append(save_path)

            elif file.endswith(".a"):
                filepath = os.path.join(parent, file)
                if filepath.find("DynamicFrameworks") == -1 & filepath.find(".bundle") == -1 & filepath.find(".framework") == -1:
                    # print("filepath :" + filepath)
                    save_path = filepath[len(sub_path):]
                    # print(" save_file_path---" + save_path)
                    lib_arr.append(save_path)

    lib_str = ''
    #作用:增加xcode group
    lib_without_houzhui_str = ''

    for i in range(len(lib_arr)):
        if i == len(lib_arr) - 1:

            root_str = lib_arr[i]

            last_index = find_last(root_str,'/')
            if last_index == -1:
               print('查找异常 ' + str(last_index))

            # index = root_str.index('.')
            target_str = root_str[:last_index]
            # if ' ' in root_str:
            #     root_str = root_str.encode(encoding='UTF-8')
            # if ' ' in target_str:
            #    target_str = target_str.encode(encoding='UTF-8')
            lib_str = lib_str + str(root_str)
            lib_without_houzhui_str = lib_without_houzhui_str + str(target_str)
        else:

            root_str = lib_arr[i]
            last_index = find_last(root_str, '/')
            if last_index == -1:
                print('查找异常 ' + str(last_index))
            # index = root_str.index('.')
            target_str = root_str[:last_index]

            # if ' ' in root_str:
            #     root_str = root_str.encode(encoding='UTF-8')
            # if ' ' in target_str:
            #     target_str = target_str.encode(encoding='UTF-8')

            lib_str = lib_str + str(root_str) + ','
            lib_without_houzhui_str = lib_without_houzhui_str + str(target_str) + ','

    print("整体传值字符窜 " + lib_str)
    print("整体传值字符窜2 " + lib_without_houzhui_str)

    # test_01_arr = lib_str.split(',')
    # test_02_arr = lib_without_houzhui_str.split(',')
    # print('第一个长度 ' + str(len(test_01_arr)) + "第二个长度 " + str(len(test_02_arr)))
    # for j in range(len(test_02_arr)):
    #     vaue = test_02_arr[j]
    #     print("index " + str(j) + "  value " + vaue)


    current_working_dir = os.getcwd()
    rb_path = 'modifyPrj/interface/addChannelLibsAndResource.rb'
    rb_path = os.path.join(current_working_dir, rb_path)

    cmd= "ruby " + rb_path + " " + xcode_proj_path + " " + target + " " + lib_str+ " " + lib_without_houzhui_str + " " + other_linker_str
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    # res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output, errors = p.communicate()
    if errors == None:
        print("-- 添加渠道库以及资源 -done---")
        print(output)
    else:
        print("-- ruby 脚本 运行错误 ---")
    print("-----渠道工程生成完毕------")
    # return 1

    logger.info('添加渠道资源 done')
    logger.info(output)

def find_last(root_string,find_str):
    last_position=-1
    while True:
        position=root_string.find(find_str,last_position+1)
        if position==-1:
            return last_position
        last_position=position
