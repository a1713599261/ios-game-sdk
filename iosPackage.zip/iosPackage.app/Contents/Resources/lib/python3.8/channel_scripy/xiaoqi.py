
def channel_config():
    json_config = {
        "group": "",
        # "frameworks": [
        #     #热云的库文件d
        #     "Security.framework",
        #     "CoreTelephony.framework",
        #     "AdSupport.framework",
        #     "SystemConfiguration.framework",
        #     "CoreMotion.framework",
        #     "iAd.framework",
        #     'AdServices.framework',
        #     'AVFoundation.framework',
        #     "CFNetwork.framework",
        #     'WebKit.framework'
        #     #热云结束
        # ],
        # "libs": [
        #     "libsqlite3.tbd",
        #     "libz.tbd",
        #     "libresolv.tbd"
        # ],
        # 动态库列表
        "DynamicFrameworks": [
            "SMSDK.framework"
        ],
        'privicy':{
            "NSPhotoLibraryAddUsageDescription":"App使用您的相册功能来保存账号密码，需要您的同意",
            'NSPhotoLibraryUsageDescription':"App使用您的相册功能来保存账号密码，需要您的同意",
            "Camera Usage Description":"App使用您的相册功能来保存账号密码，需要您的同意",
            "Microphone Usage Description":"App使用您的麦克风来完成发送语音信息，需要您的同意",
            "NSUserTrackingUsageDescription":"App使用您的广告追踪功能来实现活动消息的推送，需要您的同意"
        },
        'DCSDK': {
            'AppId': "11364",
            'AppKey': '2cf5839dd6469fd8f1184f6b543d3548',
            'DCUrl': 'http://api.gamedachen.com',
            'appSecret': 'bc297d7a718730354643442b05d423d9',
            'Channel': '12155',
            'sdkId': '99',
            'Plugins':[
            {
                "appkey":"b8636c0cf8d8fe1e2d7751e0b23eaac9",
                "name":"xiaoqi",
                "publickey":"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDIrHONgW6z1DZATqZYRHWeBeeSoEaqzUoW+ZlH1oIG19hkYe5oEs/o8yQD/vESWD/TNwTnVrqNoZRDkUxh1J6Nxc2zju1XJ57dnpDE745z/nw4fCVRLNZnl//n2kbV9mbsHvoguXJiRGWVleTxEeiQIR+T+MThuCwkqNztpr0x/wIDAQAB",
                "SMScreenMode":'1' #  1是竖屏， 0 是横屏 -默认竖屏
            }
            ]
        },
        'CFBundleURLTypes':[
            {
                'CFBundleTypeRole':"Editor",
                'CFBundleURLSchemes':[
                    "$(PRODUCT_BUNDLE_IDENTIFIER)"
                ]
            }
        ]
    }
    # $(PRODUCT_BUNDLE_IDENTIFIER)
    #合规证明
    # < key > ITSAppUsesNonExemptEncryption < / key > < false / >

    return json_config