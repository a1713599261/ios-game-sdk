# check_timeout.py
import os
import shutil
import re
import subprocess
import re
import time
import calendar

class Ios_cer_message(object):
    def __init__(self,profile_path):
        self.profile_path = profile_path

    def popen_cmd(self,cmd):
        GBK = 'gbk'
        UTF8 = 'utf-8'

        current_encoding = GBK
        popen = subprocess.Popen(cmd, shell=True,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE,
                                 bufsize=1)
        out, err = popen.communicate()
        # print(out)
        # print(err)
        # print('returncode:' + str(popen.returncode))
        return out

    def unzip_ipa(self,ipa_name):
        os.system('unzip -q ./' + ipa_name)
        os.system("codesign -d --extract-certificates Payload/*.app")

    def popen_openssl(self):
        out = self.popen_cmd('openssl x509 -inform DER -in codesign0 -noout -nameopt -oneline -dates')
        match = re.search('notAfter=(.*)', out)
        # Jan  9 02:31:00 2020 GMT
        result = match.group(1)
        match = re.search('(\w*)\s*(\w*)\s*(\w*):(\w*):(\w*)\s*(\w*)\s*GMT', result)
        m = self.month_str_to_num(match.group(1))
        d = match.group(2)
        H = match.group(3)
        M = match.group(4)
        S = match.group(5)
        Y = match.group(6)
        t = '%s-%s-%s %s:%s:%s' % (Y, m, d, H, M, S)
        # print(t)
        return self.str_to_timestamp(t), t

    def month_str_to_num(self,month_str):
        return list(calendar.month_abbr).index(month_str)

    # %Y-%m-%d %H:%M:%S
    def str_to_timestamp(self,str):
        time_array = time.strptime(str, "%Y-%m-%d %H:%M:%S")
        timeStamp = int(time.mktime(time_array))
        return timeStamp

    def delete_other_file(self):
        os.remove("codesign0")
        os.remove("codesign1")
        os.remove("codesign2")
        shutil.rmtree("Payload")

    def cat_mobileprovision(self,app_name):
        out = self.popen_cmd('cat Payload/%s/embedded.mobileprovision' % app_name)
        match = re.search('<key>ExpirationDate</key>\\n\s*<date>(.*)</date>', out)
        result = match.group(1)
        result = result.replace('T', ' ')
        result = result.replace('Z', '')
        # print(result)
        return self.str_to_timestamp(result), result

    def get_ipa(self):
        for f in os.listdir('../channel_scripy2'):
            if f.endswith('.ipa'):
                return f

    def get_payload_app(self):
        for d in os.listdir('./Payload'):
            if d.endswith('.app'):
                return d

    #获取profile文件的过期时间
    def get_mobileprovision_expirationDate(self):
        out = self.popen_cmd('cat %s' % self.profile_path)
        print('out 输出内容')
        print(out)
        # match = re.search('<key>ExpirationDate</key>\\n\s*<date>(.*)</date>', str(out))
        match = re.search('<key>ExpirationDate</key>.*<date>(.*)</date>', str(out))
        print(match)
        result = match.group(1)
        print(result)
        result = result.replace('T', ' ')
        result = result.replace('Z', '')
        # return '',''
        # print(result)
        return self.str_to_timestamp(result), result

        # 获取profile文件的相关信息
    def get_mobileprovision_message(self):
            out = self.popen_cmd('cat %s' % self.profile_path)
            # <key>Name</key>\n\t<string>dev_0928_test</string>
            out_none = re.sub(r'\\t|\\n', '', str(out))
            match = re.search(r'<key>Name</key><string>(.+?)</string>',out_none)
            profile_name = match.group(1)
            print(out_none)

            #<key>TeamIdentifier</key><array><string>KG75B2V2F7</string></array>
            team_ma = re.search(r'<key>TeamIdentifier</key><array><string>(.+?)</string></array>',out_none)
            team_identify = team_ma.group(1)
            #<key>TeamName</key><string>longping gao</string>
            team_name_ma = re.search(r'<key>TeamName</key><string>(.+?)</string>',out_none)
            team_name = team_name_ma.group(1)
            return profile_name,team_identify,team_name



# if __name__ == '__main__':
#     # ios_cer_message = Ios_cer_message()
#     # ios_cer_message.unzip_ipa(ios_cer_message.get_ipa())
#     # # unzip_ipa(get_ipa())
#     # stamp1, t1 = ios_cer_message.popen_openssl()
#     # stamp2, t2 = ios_cer_message.cat_mobileprovision(ios_cer_message.get_payload_app())
#     # ios_cer_message.delete_other_file()
#     # if stamp1 < stamp2:
#     #     print('timeout:' + t1)
#     # else:
#     #     print('timeout: ' + t2)
#     profile_path = '/Users/chenyi/Desktop/dc_files/ios_0928证书/dev_0928_test.mobileprovision'
#     class_cer = Ios_cer_message(profile_path)
#     # stamp2, t2 = class_cer.get_mobileprovision_expirationDate()
#     profile_name,team_identify,team_name = class_cer.get_mobileprovision_message()
#     print("profile_name: " + profile_name+' team_identify:' +  team_identify  + "team_name : " + team_name )