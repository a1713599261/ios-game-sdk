
def channel_config():
    json_config = {
        "group": "",
        # "frameworks": [
        #     #热云的库文件
        #     "Security.framework",
        #     "CoreTelephony.framework",
        #     "AdSupport.framework",
        #     "SystemConfiguration.framework",
        #     "CoreMotion.framework",
        #     "iAd.framework",
        #     'AdServices.framework',
        #     'AVFoundation.framework',
        #     "CFNetwork.framework",
        #     'WebKit.framework'
        #     #热云结束
        # ],
        # "libs": [
        #     "libsqlite3.tbd",
        #     "libz.tbd",
        #     "libresolv.tbd"
        # ],
        'privicy':{
            "NSPhotoLibraryAddUsageDescription":"App使用您的相册功能来保存账号密码，需要您的同意",
            'NSPhotoLibraryUsageDescription':"App使用您的相册功能来保存账号密码，需要您的同意",
            "Camera Usage Description":"App使用您的相册功能来保存账号密码，需要您的同意",
            "Microphone Usage Description":"App使用您的麦克风来完成发送语音信息，需要您的同意",
            "NSUserTrackingUsageDescription":"App使用您的广告追踪功能来实现活动消息的推送，需要您的同意"
        },
        'DCSDK': {
            'AppId': "10944",
            'AppKey': '9b09a29feb37ca4aed0bdfc463194f98',
            'DCUrl': 'http://api.gamedachen.com',
            'appSecret': 'e48d350cec9c60fa0cf3b3d64f2bb44f',
            'Channel': '12077',
            'sdkId': '88',
            'Plugins': [
                {
                    "name":"kepan",
                    'appid':'19956',
                    'appkey':'RMMQVBew9H2E7PManSyH8FsfBUtYn8n2'
                }
            ]
        },
        'CFBundleURLTypes':[
            {
                'CFBundleTypeRole':"Editor",
                'CFBundleURLSchemes':[
                    "$(PRODUCT_BUNDLE_IDENTIFIER)"
                ]
            }
        ]
    }
    # $(PRODUCT_BUNDLE_IDENTIFIER)
    #合规证明
    # < key > ITSAppUsesNonExemptEncryption < / key > < false / >

    return json_config