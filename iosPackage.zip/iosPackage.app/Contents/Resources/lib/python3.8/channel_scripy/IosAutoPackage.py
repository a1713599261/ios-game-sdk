# !/usr/bin/env python
# coding=utf-8
# 环境: UAT&SIT

import os
import re

import requests
import webbrowser
import subprocess
import time
import smtplib
import plistlib
from channel_scripy.ios_cer_message import  Ios_cer_message
from package_ui.LogUtils import *

# # 路径信息
# project_name = 'Unity-iPhone'  # 项目名称
# project_path = '/Users/chenyi/Desktop/dc_files/sdk_project/SDK_project/dc_juhe/auto_scrip/无限月读'  # 项目路径
# export_directory = '/Users/chenyi/Desktop/dc_files/sdk_project/SDK_project/dc_juhe/auto_scrip/output'  # 输出的路径
# exporrt_folder = 'auto_archive'  # 输出的文件夹

# current_working_dir = os.getcwd()
# xcodeproj_path = os.path.join(current_working_dir, export_directory)

# 蒲公英app地址、USER_KEY、API_KEY,具体见蒲公英官网: 账户设置-->API信息
ipa_download_url = 'https://www.pgyer.com/manager/dashboard/app/xxxxxxxxxxxxxxxx'
USER_KEY = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
API_KEY = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'


class AutoArchive(object):

    def __init__(self,target_name,project_path,export_directory,export_folder,plist_path,cer_type,profile_type,channel_id):

        self.logger = LogUtils.sharedInstance(channel_id)

        #打包工程 target 名称
        self.proj_target_name = target_name
        # 打包工程 路径，包含.xcoproj后缀
        self.proj_path = project_path
        # 输出路径
        self.export_directory = export_directory
        #输出文件夹 --一般会选择渠道名称作为文件夹名称
        self.export_folder = export_folder
        # 打包工程 plist 文件路径
        self.plist_path = plist_path
        # 打包工程 打包证书描述性文件profile名称
        self.profile_name = ''
        # 打包证书描述性文件 team_identify
        self.team_identify = ''
        # 打包证书描述性文件 team_名称
        self.team_name = ''
        # 打包证书类型，需要打包时候指定---  0:iPhone Distribution, 1:iPhone Developer 2:Apple Distribution 3:Apple Development
        self.cer_type = cer_type
        #profile_type -0 dev  1 adhoc 2 appstore 3 企业
        self.profile_type = profile_type


    def clean(self):

        print("\n\n===========开始clean操作===========")
        self.logger.info("\n\n===========开始clean操作===========")
        start = time.time()
        #---cocopod--
        # clean_opt = 'xcodebuild clean -workspace %s/%s.xcworkspace -scheme %s -configuration Release' % (
        # project_path, project_name, project_name)
        # ---非cocopod--
        clean_opt = 'xcodebuild clean -project %s -scheme %s -configuration Release' % (
            self.proj_path, self.proj_target_name)
        clean_opt_run = subprocess.Popen(clean_opt, shell=True)
        clean_opt_run.wait()
        end = time.time()

        self.logger.info(clean_opt_run.stdout)

        # clean 结果
        clean_result_code = clean_opt_run.returncode
        if clean_result_code != 0:
            print("===========clean失败,用时:%.2f秒===========" % (end - start))
            self.logger.info("===========clean失败,用时:%.2f秒===========" % (end - start))
        else:
            print("===========clean成功,用时:%.2f秒===========" % (end - start))
            self.logger.info("===========clean成功,用时:%.2f秒===========" % (end - start))
            self.archive()

    def archive(self):
        print("\n\n===========开始archive操作===========")
        self.logger.info("\n\n===========开始archive操作===========")

        subprocess.call(['rm', '-rf', '%s/%s' % (self.export_directory, self.export_folder)])
        time.sleep(1)
        subprocess.call(['mkdir', '-p', '%s/%s' % (self.export_directory, self.export_folder)])
        time.sleep(1)

        start = time.time()
        #cocoa-pod
        # archive_opt = 'xcodebuild archive -workspace %s/%s.xcworkspace -scheme %s -configuration Release -archivePath %s/%s' % (
        # project_path, project_name, project_name, export_directory, export_folder)
        # ---非cocopod--
        archive_opt = 'xcodebuild archive -project %s -scheme %s -configuration Release -archivePath %s/%s -destination generic/platform=ios' % (
            self.proj_path, self.proj_target_name, self.export_directory, self.export_folder)
        archive_opt_run = subprocess.Popen(archive_opt, shell=True)
        archive_opt_run.wait()
        end = time.time()

        self.logger.info(archive_opt_run.stdout)

        # archive 结果
        archive_result_code = archive_opt_run.returncode
        if archive_result_code != 0:
            print("===========archive失败,用时:%.2f秒===========" % (end - start))
            self.logger.info("===========archive失败,用时:%.2f秒===========" % (end - start))

        else:
            print("===========archive成功,用时:%.2f秒===========" % (end - start))
            self.logger.info("===========archive成功,用时:%.2f秒===========" % (end - start))

        # 导出IPA
        self.export()

    def export(self):
        print("\n\n===========开始export操作===========")
        self.logger.info("\n\n===========开始export操作===========")
        start = time.time()
        # 开始设置 最后导包 - exportOptions.plist文件--此路径将不会变更
        # dir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
        # exportOptions_plist_path = 'output/plist/exportOptions.plist'
        # exportOptions_plist_path = os.path.join(dir, exportOptions_plist_path)
        dir = os.getcwd()
        exportOptions_plist_path = 'output/plist/exportOptions.plist'
        exportOptions_plist_path = os.path.join(dir, exportOptions_plist_path)

        export_opt = 'xcodebuild -exportArchive -archivePath %s/%s.xcarchive -exportPath %s/%s -exportOptionsPlist %s' % (
        self.export_directory, self.export_folder, self.export_directory, self.export_folder,exportOptions_plist_path)
        export_opt_run = subprocess.Popen(export_opt, shell=True)
        export_opt_run.wait()
        end = time.time()

        self.logger.info(export_opt_run.stdout)

        # ipa导出结果
        export_result_code = export_opt_run.returncode
        if export_result_code != 0:
            print("===========导出IPA失败,用时:%.2f秒===========" % (end - start))
            self.logger.info("===========导出IPA失败,用时:%.2f秒===========" % (end - start))
        else:
            print("===========导出IPA成功,用时:%.2f秒===========" % (end - start))
            self.logger.info("===========导出IPA成功,用时:%.2f秒===========" % (end - start))
            ipa_folder_path = '%s/%s' % (self.export_directory, self.export_folder)
            print('ipa_folder_path==: ' + ipa_folder_path)
            self.logger.info('ipa_folder_path==: ' + ipa_folder_path)
            for parent, folders, files in os.walk(ipa_folder_path):
                for file in files:
                    if file.endswith(".ipa"):
                        filepath = os.path.join(parent, file)
                        new_name_path = self.export_directory + '/' + self.export_folder + '/' + self.export_folder + '.ipa'
                        line_change = 'mv' + ' ' + filepath + ' ' + new_name_path
                        change_run = subprocess.Popen(line_change, shell=True)
                        change_run.wait()
                        if change_run.returncode != 0:
                            print("========修改ipa文件名字失败 =============")
                        else:
                            print('======== 修改ipa 文件名字成功 新名字: ' + self.export_folder + '.ipa')
                            self.logger.info('======== ipa输出成功 名字: ' + self.export_folder + '.ipa')
                        break
                    else:
                        pass
                        # print("===========修改ipa名字失败，找不到ipa文件===========")

        # 删除archive.xcarchive文件
        subprocess.call(['rm', '-rf', '%s/%s.xcarchive' % (self.export_directory, self.export_folder)])
        # self.upload('%s/%s/ZBank.ipa' % (export_directory, export_folder))

    def upload(self, ipa_path):

        print("\n\n===========开始上传蒲公英操作===========")
        if ipa_path:

            # 蒲公英操作API
            # https://www.pgyer.com/doc/api
            url = 'http://www.pgyer.com/apiv1/app/upload'
            data = {
                'uKey': USER_KEY,
                '_api_key': API_KEY,
                'installType': '2',
                'password': "pwd",
                'updateDescription': "description"
            }
            files = {'file': open(ipa_path, 'rb')}
            r = requests.post(url, data=data, files=files)
            if r.status_code == 200:
                self.open_browser(self)

        else:
            print("\n\n===========没有找到对应的ipa===========")
            return

    @staticmethod
    # 上传成功,通过浏览器打开蒲公英网站
    def open_browser(self):
        webbrowser.open(ipa_download_url, new=1, autoraise=True)

    #打包前处理包名、证书相关
    def handel_cer(self,bid_str,cer_path,profile_path,display_name,channel_id):

        logger = LogUtils.sharedInstance(channel_id)

        print("==== 渠道plist文件路径 ==== " + self.plist_path)
        if os.path.isfile(self.plist_path):
            with open(self.plist_path, 'rb') as fp:
                plist = plistlib.load(fp, fmt=None, dict_type=dict)

                if os.path.isfile(profile_path):
                    class_cer = Ios_cer_message(profile_path)
                    self.profile_name, self.team_identify, self.team_name = class_cer.get_mobileprovision_message()
                #默认替换plistkey-包名
                common_bid = '$(PRODUCT_BUNDLE_IDENTIFIER)'
                #判断是否需要 替换包名
                if len(bid_str) > 0:
                    plist['CFBundleIdentifier']=common_bid
                    current_working_dir = os.getcwd()
                    # 获取当前脚本的上一级路径
                    up_dir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
                    rb_path = 'modifyPrj/interface/handleCer.rb'
                    rb_path = os.path.join(up_dir, rb_path)
                    print("team_identify " + self.team_identify)
                    cmd = "ruby " + rb_path + " " + self.proj_path + " " + self.proj_target_name + " " + bid_str +" " + 'cer_path' +' ' + self.profile_name+" " + str(self.cer_type) + " " + self.team_identify
                    handle_cer_opt_run = subprocess.Popen(cmd, shell=True)
                    handle_cer_opt_run.wait()
                    if handle_cer_opt_run.returncode !=0:
                        print('===== 打包证书相关配置失败 =====')
                    else:
                        print("======= 打包证书相关配置成功😊😊😊========")
                        #开始设置 最后导包 - exportOptions.plist文件
                        dir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
                        exportOptions_plist_path = 'output/plist/exportOptions.plist'
                        exportOptions_plist_path = os.path.join(dir, exportOptions_plist_path)
                        with open(exportOptions_plist_path, 'rb') as pp:
                            exportOptions_plist = plistlib.load(pp, fmt=None, dict_type=dict)
                            exportOptions_plist['teamID'] = self.team_identify
                            # profile_type -0 dev  1 adhoc 2 appstore 3 企业
                            if self.profile_type == 0:
                                exportOptions_plist['method'] = 'development'
                            elif self.profile_type == 1:
                                exportOptions_plist['method'] = 'ad-hoc'
                            elif self.profile_type == 2:
                                exportOptions_plist['method'] = 'app-store'
                            # print(exportOptions_plist)
                        with open(exportOptions_plist_path, 'wb') as gp:
                            # sort_keys 是否排序
                            plistlib.dump(value=exportOptions_plist, fp=gp, fmt=plistlib.FMT_XML, sort_keys=True, skipkeys=False)
                            gp.close()
                else:
                    #包名不需要替换的情况
                    pass

                if len(display_name):
                    plist['CFBundleDisplayName']=display_name

            with open(self.plist_path, 'wb') as fp:
                # sort_keys 是否排序
                plistlib.dump(value=plist, fp=fp, fmt=plistlib.FMT_XML, sort_keys=True, skipkeys=False)
                fp.close()

            #====开始打包操作
            self.clean()

if __name__ == '__main__':
    # description = input("请输入更新的日志描述:")
    # pwd=input("请输入蒲公英安装密码:")
    # 路径信息
    project_name = 'Unity-iPhone'  # 项目名称
    project_path = '/Users/chenyi/Desktop/dc_files/sdk_project/SDK_project/dc_juhe/auto_scrip/无限月读/Unity-iPhone.xcodeproj'  # 项目路径
    export_directory = '/Users/chenyi/Desktop/dc_files/sdk_project/SDK_project/dc_juhe/auto_scrip/output'  # 输出的路径
    exporrt_folder = 'auto_archive'  # 输出的文件夹--
    plist_path = '/Users/chenyi/Desktop/dc_files/sdk_project/SDK_project/dc_juhe/auto_scrip/无限月读/Info.plist'
    profile_path = '/Users/chenyi/Desktop/dc_files/ios_0928证书/dev_0928_test.mobileprovision'
    profile_path = '/Users/chenyi/Downloads/wuxian_yuedu_adhoc_0930.mobileprovision'
    bid_str = 'com.NY.HYYueduGame123456'
    # 打包证书类型，需要打包时候指定---  0:iPhone Distribution, 1:iPhone Developer 2:Apple Distribution 3:Apple Development
    # profile_type -0 dev  1 adhoc 2 appstore 3 企业
    cer_type, profile_type =  0,1
    archive = AutoArchive(project_name,project_path,export_directory,exporrt_folder,plist_path,cer_type,profile_type)
    archive.handel_cer(bid_str,'',profile_path,'火影修改')


