import os
import plistlib
from pbxproj import XcodeProject
# from mod_pbxproj import XcodeProject
import subprocess


copyFileCounts = 0
plugins_channel = {}

def channel_config():
    json_config = {
        "group": "",
        # "frameworks": [
        #     #热云的库文件
        #     "Security.framework",
        #     "CoreTelephony.framework",
        #     "AdSupport.framework",
        #     "SystemConfiguration.framework",
        #     "CoreMotion.framework",
        #     "iAd.framework",
        #     'AdServices.framework',
        #     'AVFoundation.framework',
        #     "CFNetwork.framework",
        #     'WebKit.framework'
        #     #热云结束
        # ],
        # "libs": [
        #     "libsqlite3.tbd",
        #     "libz.tbd",
        #     "libresolv.tbd"
        # ],
        # 动态库列表
        "DynamicFrameworks": [
            "XYChannel.framework"
        ],
        'privicy':{
            "NSPhotoLibraryAddUsageDescription":"App使用您的相册功能来保存账号密码，需要您的同意",
            'NSPhotoLibraryUsageDescription':"App使用您的相册功能来保存账号密码，需要您的同意",
            "Camera Usage Description":"App使用您的相册功能来保存账号密码，需要您的同意",
            "Microphone Usage Description":"App使用您的麦克风来完成发送语音信息，需要您的同意",
            "NSUserTrackingUsageDescription":"App使用您的广告追踪功能来实现活动消息的推送，需要您的同意"
        },
        'DCSDK':{
            'AppId':"",
            'AppKey':'',
            'Channel':'',
            'DCUrl':'',
            'appSecret':'',
            'sdkId':'',
            'Plugins': [
                {
                    "pid": "23056",
                    "gid": "5752",
                    "name": "XinYou5144",
                }
            ]
        },
        'CFBundleURLTypes':[
            {
                'CFBundleTypeRole':"Editor",
                'CFBundleURLSchemes':[
                    "$(PRODUCT_BUNDLE_IDENTIFIER)"
                ]
            }
        ]
    }
    # $(PRODUCT_BUNDLE_IDENTIFIER)
    #合规证明
    # < key > ITSAppUsesNonExemptEncryption < / key > < false / >
    return json_config

def copyFiles(sourceDir, targetDir):
 global copyFileCounts
 #print (u"%s 当前处理文件夹%s已处理%s 个文件" %(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())), sourceDir,copyFileCounts))
 for f in os.listdir(sourceDir):
  sourceF = os.path.join(sourceDir, f)
  targetF = os.path.join(targetDir, f)
  if os.path.isfile(sourceF):
   #创建目录
   if not os.path.exists(targetDir):
    os.makedirs(targetDir)
   copyFileCounts += 1
   #文件不存在，或者存在但是大小不同，覆盖
   if not os.path.exists(targetF) or (os.path.exists(targetF) and (os.path.getsize(targetF) != os.path.getsize(sourceF))):
    #2进制文件
    open(targetF, "wb").write(open(sourceF, "rb").read())
    #print (u"%s %s 复制完毕" %(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())), targetF))
   else:
    #print (u"%s %s 已存在，不重复复制" %(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())), targetF))
     print("")
  if os.path.isdir(sourceF):
   copyFiles(sourceF, targetF)
#将渠道资源复制到target工程
def handel_channel_libsAndResource(xcode_proj_path,target,plist_path,channel_resource):
    print('xcode' + xcode_proj_path)
    parent_plist_parth = os.path.dirname(plist_path)
    targetResource = parent_plist_parth + "/" + channel_resource

    current_working_dir = os.getcwd()
    sdkReource_path   =  "channels/" + channel_resource
    sdkReource_path   = os.path.join(current_working_dir, sdkReource_path)

    copyFiles(sdkReource_path,targetResource)

    xcode_proj_path = os.path.join(xcode_proj_path, "project.pbxproj")
    my_project = XcodeProject.load(xcode_proj_path)
    # my_project.get_or_create_group('dcLianyun_old')
    # file_options = FileOptions(weak=True)
    print("渠道文件路径：" + targetResource)

    for parent, folders, files in os.walk(targetResource):
        for folder in folders:
            if folder.endswith(".bundle") | folder.endswith(".framework"):
                folderpath = os.path.join(parent, folder)
                if parent.find(".framework") == -1:
                    print("folderpath :" + folderpath)
                    my_project.add_file(path=folderpath)

                # elif parent.find(".bundle") != -1:
                #     print("folderpath :" + folderpath)
                #     # my_project.add_file(path=folderpath)

        for file in files:
            if  file.endswith(".png") | file.endswith(".jpg") | file.endswith(".plist"):
                filepath = os.path.join(parent, file)
                if filepath.find(".bundle") == -1 & filepath.find(".framework") == -1:
                    print("filepath :" + filepath)
                    my_project.add_file(path=filepath)
            elif file.endswith(".a"):
                filepath = os.path.join(parent, file)
                print("filepath :" + filepath)
                my_project.add_file(path=filepath)

    # my_project.add_folder(path=targetResource)
    # my_project.add_file(path=targetResource)
    my_project.save(xcode_proj_path)

    print("-----渠道工程生成完毕------")
    return 1

    # current_working_dir = os.getcwd()
    # rb_path = 'modifyPrj/interface/addEntitlements.rb'
    # rb_path = os.path.join(current_working_dir, rb_path)
    # cmd = "ruby " + rb_path + " " + xcode_proj_path + " " + target + " " + rb_path
    # p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    # # res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    # output, errors = p.communicate()
    # if errors == None:
    #     print("-- 添加渠道文件-done---")
    #     print(output)
    # else:
    #     print("-- ruby 脚本 运行错误 ---")

#添加系统库
def handel_libs(xcode_proj_path,targetName,plistConfig):
    print('工程路径:' + xcode_proj_path)
    target = targetName
    lib_arr = []
    change_plist_content = plistConfig
    for v in change_plist_content['libs']:
        lib_arr.append(v)

    for v in change_plist_content['frameworks']:
        lib_arr.append(v)

    lib_str = ''
    for i in range(len(lib_arr)):
        if i == len(lib_arr) - 1:
            lib_str = lib_str + lib_arr[i]
        else:
            lib_str = lib_str + lib_arr[i] + ','

    current_working_dir = os.getcwd()
    rb_path = 'modifyPrj/interface/addSystemFrameworks.rb'
    rb_path = os.path.join(current_working_dir,rb_path)
    print(lib_str)

    cmd = "ruby " + rb_path +" " + xcode_proj_path + " "  + target + " " + lib_str
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    # res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output, errors = p.communicate()
    if errors == None:
        print("-- 添加系统库 -done---")
        print(output)
    else:
        print("-- ruby 脚本 运行错误 ---")


def handel_plist(plist_path,plistConfig):

    global plugins_channel
    change_plist_content = plistConfig
    privicy = plistConfig['privicy']
    channel_param = plistConfig['DCSDK']
    url_type = plistConfig['CFBundleURLTypes']

    find_key = 'DCSDK'
    if os.path.isfile(plist_path):
        with open(plist_path, 'rb') as fp:
            plist = plistlib.load(fp, fmt=None, dict_type=dict)
            if len(privicy) >0:
               for k in privicy:
                   plist[k] = privicy[k]
            else:
                print("----请先接入--聚合SDK")
                exit(0)
            plist[find_key]  = channel_param
            #xiaoqi 渠道额外添加横竖屏 判断
            plugins_channel = plist[find_key]['Plugins'][0]
            if plugins_channel.keys().__contains__('SMScreenMode'):
                plist['SMScreenMode'] = plugins_channel['SMScreenMode']
            if plist.keys().__contains__('CFBundleURLTypes'):
                temp = []
                for k in plist['CFBundleURLTypes']:
                    temp.append(k)
                for value in url_type:
                    temp.append(value)
                plist['CFBundleURLTypes'] = temp
            else:
                plist['CFBundleURLTypes'] = url_type

        #添加白名单
            if plistConfig.keys().__contains__('LSApplicationQueriesSchemes'):
                schemes = plistConfig['LSApplicationQueriesSchemes']
                if plist.keys().__contains__('LSApplicationQueriesSchemes'):
                    temp = []
                    for k in plist['LSApplicationQueriesSchemes']:
                        temp.append(k)
                    for value in schemes:
                        temp.append(value)
                    plist['LSApplicationQueriesSchemes'] = temp
                else:
                    plist['LSApplicationQueriesSchemes'] = schemes
        with open(plist_path, 'wb') as fp:
            # sort_keys 是否排序
            plistlib.dump(value=plist, fp=fp, fmt=plistlib.FMT_XML, sort_keys=True, skipkeys=False)

    #-----只替换plugin的处理方式
    # if os.path.isfile(plist_path):
    #
    #     with open(plist_path, 'rb') as fp:
    #         plist = plistlib.load(fp, fmt=None, dict_type=dict)
    #         if len(privicy) >0:
    #            for k in privicy:
    #                plist[k] = privicy[k]
    #         plist[find_key]['Plugins']  = plugins
    #         if plist.keys().__contains__('CFBundleURLTypes'):
    #             temp = []
    #             for k in plist['CFBundleURLTypes']:
    #                 temp.append(k)
    #             temp.append(url_type[0])
    #             plist['CFBundleURLTypes'] = temp
    #         else:
    #             plist['CFBundleURLTypes'] = url_type
    #
    #     with open(plist_path, 'wb') as fp:
    #         # sort_keys 是否排序
    #         plistlib.dump(value=plist, fp=fp, fmt=plistlib.FMT_XML, sort_keys=True, skipkeys=False)
        # print(plist)