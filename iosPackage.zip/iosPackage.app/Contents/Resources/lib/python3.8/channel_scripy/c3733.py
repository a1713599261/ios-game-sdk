
def channel_config():
    json_config = {
        "group": "lianyunold",
        "frameworks": [
            #支付宝库文件-开始
            'SystemConfiguration.framework',
            'CoreTelephony.framework',
            'QuartzCore.framework',
            'CoreGraphics.framework',
            'UIKit.framework',
            'Foundation.framework',
            'CFNetwork.framework',
            'CoreMotion.framework'
            # 支付宝库文件-结束
        ],
        "libs": [
            #支付宝库文件-开始
            "libz.tbd",
            "libc++.tbd"
            # 支付宝库文件-结束
        ],
        "DynamicFrameworks": [
            "YY3733NewSDK.framework"
        ],
        'privicy':{
            "NSPhotoLibraryAddUsageDescription":"App使用您的相册功能来保存账号密码，需要您的同意",
            'NSPhotoLibraryUsageDescription':"App使用您的相册功能来保存账号密码，需要您的同意",
            "Camera Usage Description":"App使用您的相册功能来保存账号密码，需要您的同意",
            "Microphone Usage Description":"App使用您的麦克风来完成发送语音信息，需要您的同意",
        },
        'DCSDK': {
            'AppId': "10944",
            'AppKey': '9b09a29feb37ca4aed0bdfc463194f98',
            'DCUrl': 'http://api.gamedachen.com',
            'appSecret': 'e48d350cec9c60fa0cf3b3d64f2bb44f',
            'Channel': '12081',
            'sdkId': '119',
            'Plugins': [
                {
                    "name":"3733",
                    'appKey':'',
                    'appID':'',
                    'agentgame':'',
                    'clientKey':'',
                    'isLandscape':'',
                    'clientID':''
                }
            ]
        },
        'LSApplicationQueriesSchemes': [
            '3733gamebox',
            'a3733gamebox',
            'weixin',
            'alipay',
            'wechat',
            'safepay',
            'uppaysdk',
            'uppaywallet',
            'uppayx1',
            'uppayx2',
            'uppayx3',
            'mqqapi',
            'alipayqr',
            'alipays'
        ],
        'CFBundleURLTypes':[
            {
                'CFBundleTypeRole':"Editor",
                'CFBundleURLSchemes':[
                    "$(PRODUCT_BUNDLE_IDENTIFIER).3733.com"
                ]
            }
        ]
    }
    # $(PRODUCT_BUNDLE_IDENTIFIER)
    #合规证明
    # < key > ITSAppUsesNonExemptEncryption < / key > < false / >

    return json_config