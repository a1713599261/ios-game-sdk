def channel_config():
    json_config = {
        "group": "lianyunold",
        "frameworks": [
            #热云的库文件
            "Security.framework",
            "CoreTelephony.framework",
            "AdSupport.framework",
            "SystemConfiguration.framework",
            "CoreMotion.framework",
            "iAd.framework",
            'AdServices.framework',
            'AVFoundation.framework',
            "CFNetwork.framework",
            'WebKit.framework'
            #热云结束
        ],
        #动态库列表
        "DynamicFrameworks": [
            "SYSDK.framework",
            'Channel_ygme.framework'
        ],
        "libs": [
            "libsqlite3.tbd",
            "libz.tbd",
            "libresolv.tbd",
            "libc++.1.tbd"
        ],

        # 'preprocessor_macros': [
        #     "HAVE_CONFIG_H"
        # ],
        # 'other_linker':[
        #     '-lsqlite3.0'
        # ],
        'privicy':{
            "NSPhotoLibraryAddUsageDescription":"App使用您的相册功能来保存账号密码，需要您的同意",
            'NSPhotoLibraryUsageDescription':"App使用您的相册功能来保存账号密码，需要您的同意",
            "Camera Usage Description":"App使用您的相册功能来保存账号密码，需要您的同意",
            "Microphone Usage Description":"App使用您的麦克风来完成发送语音信息，需要您的同意",
            "NSUserTrackingUsageDescription":"App使用您的广告追踪功能来实现活动消息的推送，需要您的同意",
            "UIUserInterfaceStyle":"Light" # 禁止 深色模式
        },

        'LSApplicationQueriesSchemes': [
            'mqq'
        ],
        'DCSDK': {
            'AppId': "11398",
            'AppKey': '0879e78b54b59b0c0271a17c714be9b4',
            'DCUrl': 'https://msdkapi.h123jtGame.com',
            'appSecret': '8ba849b2bd512ba0a1f9a6bc35fb3343',
            'Channel': '12260',
            'sdkId': '86',
            'Plugins':[
            {
                "productKey":"41c89661eb5e404e9120ee6f0d5ac796",
                "name":"ygme",
                "channelId":"103",
                "productId":"2685",
                "rootServer":"https://sdkapi.h123jtgame.com/"
            }
            ]
        },
        'CFBundleURLTypes':[
            {
                'CFBundleTypeRole':"Editor",
                'CFBundleURLSchemes':[
                    "$(PRODUCT_BUNDLE_IDENTIFIER)"
                ]
            }
        ]
    }
    # $(PRODUCT_BUNDLE_IDENTIFIER)
    #合规证明
    # < key > ITSAppUsesNonExemptEncryption < / key > < false / >

    return json_config