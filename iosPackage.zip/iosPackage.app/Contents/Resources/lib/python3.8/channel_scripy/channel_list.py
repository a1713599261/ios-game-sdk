
import  json,os

def channel_list_chose():
    # 读取json文件内容,返回字典格式

    channel_list = []
    work_dir = os.getcwd()
    channel_json_file_path = os.path.join(work_dir,'channel_name.json')
    with open(channel_json_file_path, 'r', encoding='utf8')as fp:
        json_data = json.load(fp)
        for index in range(len(json_data)):
            value = json_data[index]
            index_id = value['id']
            index_name = value['name']
            show_name = str(index_id) + " " + index_name
            channel_list.append(show_name)
    return channel_list,json_data