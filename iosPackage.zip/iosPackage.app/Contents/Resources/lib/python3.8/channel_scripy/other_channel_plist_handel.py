
import os
import subprocess
import plistlib

class channel_plist_handel(object):
      def __init__(self,channel_resource_dir,channel_id,plugin_param):
          self.channel_resource_dir = channel_resource_dir #目标资源文件夹
          self.channel_param_plist_name  = '' #参数plist文件名称
          self.channel_id = channel_id
          self.plugin_param = plugin_param
          # 飞剑随便玩
          if channel_id == '21' or channel_id == '18' or channel_id == '7':
              self.channel_param_plist_name = 'HuoSdkConfig.plist'
              for parent, folders, files in os.walk(self.channel_resource_dir):
                  for file in files:
                      if file == self.channel_param_plist_name:
                          self.plist_path  = os.path.join(parent, file)
                          self.channel_plist_set_param()
                          break

          # 咪噜 --milu
          if channel_id == '9':
             self.channel_param_plist_name = 'MY.plist'
             for parent, folders, files in os.walk(self.channel_resource_dir):
                 for file in files:
                     if file == self.channel_param_plist_name:
                        self.plist_path = os.path.join(parent, file)
                        self.channel_plist_set_param()
                        break

          #=== 幻夜渠道 ====
          if channel_id == '24' or channel_id == '23' or channel_id == '13' \
                  or channel_id == '20' or channel_id == '19'or channel_id == '12':
              self.channel_param_plist_name = 'WC.plist'
              for parent, folders, files in os.walk(self.channel_resource_dir):
                  for file in files:
                       if file == self.channel_param_plist_name:
                          self.plist_path = os.path.join(parent, file)
                          self.channel_plist_set_param()
                          break


      def channel_plist_set_param(self):
          with open(self.plist_path, 'rb') as fp:
              plist = plistlib.load(fp, fmt=None, dict_type=dict)
              for (key, value) in self.plugin_param.items():
                  if key == 'name':
                      pass
                  else:
                      plist[key] = value

          with open(self.plist_path, 'wb') as fp:
              # sort_keys 是否排序
              plistlib.dump(value=plist, fp=fp, fmt=plistlib.FMT_XML, sort_keys=True, skipkeys=False)
              fp.close()

