
def channel_config():
    json_config = {
        "group": "",
        "frameworks": [
            'AdSupport.framework',
            'StoreKit.framework',
            'JavaScriptCore.framework',
            # 支付宝库文件-开始
            'SystemConfiguration.framework',
            'CoreTelephony.framework',
            'QuartzCore.framework',
            'CoreGraphics.framework',
            'UIKit.framework',
            'Foundation.framework',
            'CFNetwork.framework',
            'CoreMotion.framework'
            # 支付宝库文件-结束
        ],
        "libs": [
            "libsqlite3.tbd",
            "libz.tbd",
            "libc++.tbd"
        ],
        'privicy':{
            "NSPhotoLibraryAddUsageDescription":"App使用您的相册功能来保存账号密码，需要您的同意",
            'NSPhotoLibraryUsageDescription':"App使用您的相册功能来保存账号密码，需要您的同意",
            "Camera Usage Description":"App使用您的相册功能来保存账号密码，需要您的同意",
            "Microphone Usage Description":"App使用您的麦克风来完成发送语音信息，需要您的同意",
            "NSUserTrackingUsageDescription":"App使用您的广告追踪功能来实现活动消息的推送，需要您的同意"
        },
        'DCSDK': {
            'AppId': "10944",
            'AppKey': '9b09a29feb37ca4aed0bdfc463194f98',
            'DCUrl': 'http://api.gamedachen.com',
            'appSecret': 'e48d350cec9c60fa0cf3b3d64f2bb44f',
            'Channel': '12080',
            'sdkId': '114',
            'Plugins': [
                {
                    "name": "milu",
                    'MAIY_AGENT':'',
                    'MAIY_APPID':'',
                    'MAIY_GAMEID':''
                }
            ]
        },
        'CFBundleURLTypes':[
            {
                'CFBundleTypeRole':"Editor",
                'CFBundleURLName':"MY",
                'CFBundleURLSchemes':[
                    "MYAliPayScheme"#7188指渠道参数gameid
                ]
            },
            {
                'CFBundleTypeRole': "Editor",
                'CFBundleURLName': "weixin",
                'CFBundleURLSchemes': [
                    "wx0f6557acf2f490ac"
                ]
            }
        ]
    }
    # $(PRODUCT_BUNDLE_IDENTIFIER)
    #合规证明
    # < key > ITSAppUsesNonExemptEncryption < / key > < false / >

    return json_config