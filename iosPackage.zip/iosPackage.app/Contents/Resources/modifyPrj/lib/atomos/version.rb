# frozen_string_literal: true

module Atomos
#  VERSION = File.read(File.expand_path('../../../VERSION', __FILE__))
end
