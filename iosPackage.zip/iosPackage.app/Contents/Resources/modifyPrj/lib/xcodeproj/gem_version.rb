module Xcodeproj
  # The version of the xcodeproj gem.
  #
  VERSION = '1.17.1'.freeze unless defined? Xcodeproj::VERSION
end
