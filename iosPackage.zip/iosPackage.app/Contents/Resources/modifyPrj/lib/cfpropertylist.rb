# -*- coding: utf-8 -*-

require 'cfpropertylist/rbCFPropertyList'


# eof
