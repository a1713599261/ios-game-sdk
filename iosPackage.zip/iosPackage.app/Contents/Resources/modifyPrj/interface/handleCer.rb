def handleProjCer(project, target,bid_str,cer,profile,cer_type,team_identify)
    puts "处理证书相关"
#     puts project,target,frameworksPath
    require File.dirname(__FILE__)+'/../lib/xcodeproj'

    begin
    proj = Xcodeproj::Project.open(project)
    targetNode = proj.targets.first
    if proj.targets.first.name != target then
        for i in proj.targets
            if i.name == target then
                targetNode = i
                break
            end
        end
    end
    if bid_str  then
       puts "-ruby开始替换包名------"
       targetNode.build_configuration_list.set_setting('PRODUCT_BUNDLE_IDENTIFIER', bid_str)
    end

    puts "-ruby设置证书自选===="
    #Automatic 自动匹配   Manual 自选
    targetNode.build_configuration_list.set_setting('ProvisioningStyle', 'Manual')
    targetNode.build_configuration_list.set_setting('CODE_SIGN_STYLE','Manual')

    #替换证书team名称
#     targetNode.build_configuration_list.set_setting('DEVELOPMENT_TEAM',team_name)
    #替换证书 0:iPhone Distribution, 1:iPhone Developer 2:Apple Distribution 3:Apple Development
    cer_p_type = Integer(cer_type)
    if cer_p_type == 0 then
       targetNode.build_configuration_list.set_setting('CODE_SIGN_IDENTITY','iPhone Distribution')
       targetNode.build_configuration_list.set_setting('CODE_SIGN_IDENTITY[sdk=iphoneos*]','iPhone Distribution')
#        CODE_SIGN_IDENTITY[sdk=iphoneos*]
    elsif cer_p_type == 1 then
       targetNode.build_configuration_list.set_setting('CODE_SIGN_IDENTITY','iPhone Developer')
       targetNode.build_configuration_list.set_setting('CODE_SIGN_IDENTITY[sdk=iphoneos*]','iPhone Developer')
    elsif cer_p_type == 2 then
       targetNode.build_configuration_list.set_setting('CODE_SIGN_IDENTITY','Apple Distribution')
       targetNode.build_configuration_list.set_setting('CODE_SIGN_IDENTITY[sdk=iphoneos*]','Apple Distribution')
    elsif cer_p_type == 3 then
       targetNode.build_configuration_list.set_setting('CODE_SIGN_IDENTITY','Apple Development')
       targetNode.build_configuration_list.set_setting('CODE_SIGN_IDENTITY[sdk=iphoneos*]','Apple Distribution')
    end

    #设置证书profile 名称
    #PROVISIONING_PROFILE_SPECIFIER
    #PROVISIONING_PROFILE
    targetNode.build_configuration_list.set_setting('PROVISIONING_PROFILE',profile)
    targetNode.build_configuration_list.set_setting('PROVISIONING_PROFILE_SPECIFIER',profile)

    #设置证书team_team_identify--- DEVELOPMENT_TEAM
    targetNode.build_configuration_list.set_setting('DEVELOPMENT_TEAM',team_identify)

    proj.save
    end
end
handleProjCer(ARGV[0], ARGV[1], ARGV[2],ARGV[3],ARGV[4],ARGV[5],ARGV[6])