def addChannelLibs(project, target, frameworksPath,frameworks_wuhouzhui,other_linker)
    puts "项目 target 添加渠道.a .frameworks .bundle"
#     puts project,target,frameworksPath
    require File.dirname(__FILE__)+'/../lib/xcodeproj'

    begin
    proj = Xcodeproj::Project.open(project)
    targetNode = proj.targets.first
    if proj.targets.first.name != target then
        for i in proj.targets
            if i.name == target then
                targetNode = i
                break
            end
        end
    end

    #将bitcode 设置为NO
    targetNode.build_configuration_list.set_setting('ENABLE_BITCODE', false)
    frameworkArray = frameworksPath.split(',')
    frameworks_wuhouzhiu_arr = frameworks_wuhouzhui.split(',')


    if other_linker  then
       puts "-ruby开始 添加linker other flag------"
       linker_arr = other_linker.split(',')
       linker_path = targetNode.build_configuration_list.get_setting('OTHER_LDFLAGS')
       linker_str_new = ''
       for linker_str in linker_arr
           if linker_path['Release'] then
             linker_str_new = linker_path['Release']
           end
           if linker_str_new == '' then
                linker_str_new = linker_str
           else
                linker_str_new << ' ' << linker_str
           end
           targetNode.build_configuration_list.set_setting('OTHER_LDFLAGS', linker_str_new)
       end
    end

    index = 0
    for framework in frameworkArray

        suffix = framework.scan(/\.[^\.]+$/)[0]
        frame_name = frameworks_wuhouzhiu_arr[index]
        #找到要插入的group (参数中true表示如果找不到group，就创建一个group)
        group = proj.main_group.find_subpath(File.join(frame_name),true)
        #set一下sorce_tree
        group.set_source_tree('SOURCE_ROOT')
        if suffix == '.a' then
           #添加xx.a的引用
#            file_ref = targetNode.frameworks_group.new_file(framework)
#            targetNode.frameworks_build_phases.add_file_reference(file_ref)
           file_ref = group.new_reference(framework, 'SOURCE_ROOT')
           targetNode.frameworks_build_phases.add_file_reference(file_ref)

           print "add .a search path\n"
             #添加framework search path
             frameworkSearchPaths = targetNode.build_configuration_list.get_setting('LIBRARY_SEARCH_PATHS')
             print "初始的search path\n"
             puts(frameworkSearchPaths)
            #    frameworkPath = '"' << File.expand_path("..",framework) << '"'
            releaseFrameworkSearch = ''
            framework_path_xiangdui = '$(PROJECT_DIR)/' + frame_name
            if frameworkSearchPaths['Release'] then
             releaseFrameworkSearch = frameworkSearchPaths['Release']
            end
            if releaseFrameworkSearch == '' then
#         releaseFrameworkSearch = frameworkPath
                 releaseFrameworkSearch = framework_path_xiangdui
            else
    #如果没有传入framework路径，添加这个会导致添加一个类似无用路径 "/Users/0280106pc0008/Library/Developer/Xcode/DerivedData/QuickTool-eyasmumbnsivsvbqfkrysromtggj/Build/Products/Debug/QuickTool.app/Contents/Resources/modifyPrj"
                 releaseFrameworkSearch << ' ' << framework_path_xiangdui
            end
            print "最终的search path\n"
            puts(releaseFrameworkSearch)
            targetNode.build_configuration_list.set_setting('LIBRARY_SEARCH_PATHS', releaseFrameworkSearch)

        elsif suffix == '.bundle' || suffix == '.plist'|| suffix == '.jpg'|| suffix == '.png' || suffix == '.nib' || suffix == '.TTF' then
             #添加xx.bundle的引用
#              file_ref = proj.frameworks_group.new_file(framework)
             file_ref = group.new_reference(framework, 'SOURCE_ROOT')
             targetNode.resources_build_phase.add_file_reference(file_ref)

        elsif suffix == '.framework' then
#              file_ref = proj.frameworks_group.new_file(framework)
             file_ref = group.new_reference(framework, 'SOURCE_ROOT')
             targetNode.frameworks_build_phases.add_file_reference(file_ref)

             print "add framework search path\n"
             #添加framework search path
             frameworkSearchPaths = targetNode.build_configuration_list.get_setting('FRAMEWORK_SEARCH_PATHS')
             print "初始的search path\n"
             puts(frameworkSearchPaths)
            #    frameworkPath = '"' << File.expand_path("..",framework) << '"'
            releaseFrameworkSearch = ''
            framework_path_xiangdui = '$(PROJECT_DIR)/' + frame_name
            if frameworkSearchPaths['Release'] then
             releaseFrameworkSearch = frameworkSearchPaths['Release']
            end
            if releaseFrameworkSearch == '' then
#         releaseFrameworkSearch = frameworkPath
                 releaseFrameworkSearch = framework_path_xiangdui
            else
    #如果没有传入framework路径，添加这个会导致添加一个类似无用路径 "/Users/0280106pc0008/Library/Developer/Xcode/DerivedData/QuickTool-eyasmumbnsivsvbqfkrysromtggj/Build/Products/Debug/QuickTool.app/Contents/Resources/modifyPrj"
                 releaseFrameworkSearch << ' ' << framework_path_xiangdui
            end
            print "最终的search path\n"
            puts(releaseFrameworkSearch)
            targetNode.build_configuration_list.set_setting('FRAMEWORK_SEARCH_PATHS', releaseFrameworkSearch)

        elsif suffix == '.m' ||  suffix == '.mm' || suffix == '.h' || suffix == '.c' then

             #向group中增加文件引用（.h文件只需引用一下，.m引用后还需add一下）
             file_ref = group.new_reference(framework,'SOURCE_ROOT')
#               file_ref = group.new_reference('xxxPath/xx.m')
             #----飞剑sdk 有个 OpenUDID.m 需要增加 非arc 模式
#              target.add_file_references([file_ref],'-fno-objc-arc')
             if framework["OpenUDID.m"] then
                ret = targetNode.add_file_references([file_ref],'-fno-objc-arc')
             else
                ret = targetNode.add_file_references([file_ref])
             end
        end
        index= index + 1
    end
    end
    print "save project\n"
    proj.save
    print "after save\n"
end

addChannelLibs(ARGV[0], ARGV[1], ARGV[2],ARGV[3],ARGV[4])


