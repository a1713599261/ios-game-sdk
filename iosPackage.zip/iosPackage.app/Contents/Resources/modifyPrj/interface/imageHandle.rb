
def image_add(project, target, imagePath,folderName,old_image_name)
    puts "项目 target 添加渠道.a .frameworks .bundle"
#     puts project,target,frameworksPath
    require File.dirname(__FILE__)+'/../lib/xcodeproj'

    begin
    proj = Xcodeproj::Project.open(project)
    targetNode = proj.targets.first
    if proj.targets.first.name != target then
        for i in proj.targets
            if i.name == target then
                targetNode = i
                break
            end
        end
    end
    #找到要插入的group (参数中true表示如果找不到group，就创建一个group)
    removeGroup = proj.main_group.find_subpath(old_image_name, true)
#     removeGroup.set_source_tree('<group>')
    puts removeGroup
#     file_ref = group.new_reference(removeGroup, 'SOURCE_ROOT')
    removeGroup.remove_file_reference(old_image_name)
    targetNode.frameworks_build_phases.remove_file_reference(old_image_name)
#     removeGroup.clear()
#     if !removeGroup.empty? then
#         process_group_remove_path(targetNode, removeGroup)
#         removeGroup.clear()
#     end


#     group = proj.main_group.find_subpath(File.join(folderName),true)
#     targetNode.
#     group.remo
#     file_ref = group.new_reference(framework, 'SOURCE_ROOT')
#     targetNode.frameworks_build_phases.add_file_reference(file_ref)
    end
    print "save project\n"
    proj.save
    print "after save\n"
end

def process_group_remove_path(aTarget, aGroup)
    puts "\nprocess_group_remove_path..."
    aGroup.files.each do |file|
        aTarget.resources_build_phase.remove_file_reference(file)
    end

    aGroup.groups.each do |group|
        process_group_remove_path(aTarget,group)
    end
end

image_add(ARGV[0], ARGV[1], ARGV[2],ARGV[3],ARGV[4])


