def handleOthers(project, target,channel_name,event)
    puts "处理渠道的一些特殊配置"
#     puts project,target,frameworksPath
    require File.dirname(__FILE__)+'/../lib/xcodeproj'

    begin
    proj = Xcodeproj::Project.open(project)
    targetNode = proj.targets.first
    if proj.targets.first.name != target then
        for i in proj.targets
            if i.name == target then
                targetNode = i
                break
            end
        end
    end

    #飞剑—随便玩渠道添加 macros_header
    if channel_name == 'feijian_suibianwan'  then
       puts "-ruby开始 添加 macros_header------"
       macros_header_str = ''
       proj_macros_header = targetNode.build_configuration_list.get_setting('GCC_PREPROCESSOR_DEFINITIONS')
       if proj_macros_header['Release'] then
            macros_header_str = proj_macros_header['Release']
       end
       if macros_header_str == '' then
            macros_header_str = event
       else
            macros_header_str << ' ' << event
       end
       targetNode.build_configuration_list.set_setting('GCC_PREPROCESSOR_DEFINITIONS', macros_header_str)
    end

    proj.save
    end
end
handleOthers(ARGV[0], ARGV[1], ARGV[2],ARGV[3])

