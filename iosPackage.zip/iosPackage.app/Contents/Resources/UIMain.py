#!/usr/bin/env python
# -*-coding:utf-8 -*-
import wx
import os
# from utils.ConfigUtils import *
from package_ui.JChannelSDKListPanelUI import JChannelSDKListPanel
from package_ui.JChannelPanelUI import JChannelPanel
from package_ui.PackageIPAUI import PackageIPAPanel
from package_ui.ToolBarEventListener import ToolBarEventListener


TOOL_TITLE = u'iOS聚合打渠道包工具'

# 显示主页面
class GuiMainFrame(wx.Frame):

    def __init__(self, frame_size, flag=True):
        wx.Frame.__init__(self, parent=None, id=-1, title=TOOL_TITLE, size=frame_size)
        self.Center()  # 窗口居中


        '''渠道数据保存格式'''
        self.curreent_chose_channel_id = ''
        self.history_channel_data = {}
        # channel_data = {}
        # channel_data['channel_param'] = {}
        # channel_data['channel_cer'] = {'profile_path':'',
        #                                'profile_type':'',
        #                                'cer_type':''}
        #
        # self.history_channel_data['xcode_proj_path'] = ''
        # self.history_channel_data['plist_path'] = ''
        # self.history_channel_data['target_name'] = ''
        # self.history_channel_data['profile_path'] = ''
        # self.history_channel_data['profile_type'] = ''
        # self.history_channel_data['cer_type'] = ''
        # self.history_channel_data['folder_path'] = ''
        # self.history_channel_data['channel_id 例如 1 '] = {}


        # 将窗体传递到子控件
        self.windowFrame = self

        self.first = 0
        self.flag = flag

        self.width = self.Size.width
        self.height = self.Size.height

        self.up = self.height/2  # 上面窗口高度
        self.left = (self.width/5)*2  # 嵌套窗口左窗口宽度

        self.spWindow = wx.SplitterWindow(self, size=(self.width, self.height))  # 创建一个主分割窗体, parent是frame, 区分上下两部分
        self.up_panel = wx.Panel(self.spWindow)  # 创建上半部分面板
        self.down_panel = PackageIPAPanel(self.spWindow, self.windowFrame)  # 创建下半部分面板


        self.child_spWindow = wx.SplitterWindow(self.up_panel)  # 创建一个子分割窗, parent是up_panel, 区分上半区左右部分
        self.child_layout = wx.BoxSizer(wx.VERTICAL)  # 创建一个垂直布局
        self.child_layout.Add(self.child_spWindow, 1, wx.EXPAND)  # 将子分割窗布局延伸至整个p1空间
        self.up_panel.SetSizer(self.child_layout)

        self.resourcePanel = JChannelSDKListPanel(self.child_spWindow, self.windowFrame, self.up_data_ui)  # 在子分割窗上创建左面板
        # self.channelPanel = JChannelPanel(self.child_spWindow, self.windowFrame, self.up_data_ui)  # 在子分割窗上创建右面板
        self.channelPanel = JChannelPanel(self.child_spWindow, self.windowFrame, self.up_data_ui, self.history_channel_data,
                      self.save_channel_data_fun,self.chose_image_fun,self.curreent_chose_channel_id)  # 创建新的面板

        self.spWindow.SplitHorizontally(self.up_panel, self.down_panel, 0)
        self.child_spWindow.SplitVertically(self.resourcePanel, self.channelPanel, self.left)
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.on_erase_back)

        # 工具栏
        self.ToolBar = wx.ToolBar(self, wx.ID_ANY, style=wx.TB_HORZ_LAYOUT | wx.TB_TEXT)  # 创建工具栏对象
        toolbar_size = (30, 28)  # 设置工具栏图标大小

        # 创建图标
        open_game_apk_bmp = wx.ArtProvider.GetBitmap(wx.ART_PLUS, wx.ART_TOOLBAR, toolbar_size)
        set_output_dir_bmp = wx.ArtProvider.GetBitmap(wx.ART_FILE_OPEN, wx.ART_TOOLBAR, toolbar_size)
        down_sdk_bmp = wx.ArtProvider.GetBitmap(wx.ART_GO_DOWN, wx.ART_TOOLBAR, toolbar_size)
        set_sign_file_bmp = wx.ArtProvider.GetBitmap(wx.ART_FIND_AND_REPLACE, wx.ART_TOOLBAR, toolbar_size)
        tool_help_bmp = wx.ArtProvider.GetBitmap(wx.ART_HELP, wx.ART_TOOLBAR, toolbar_size)

        # 将这图标放入工具栏
        self.ToolBar.AddTool(200, u'导入游戏', open_game_apk_bmp, u'导入游戏')
        self.ToolBar.AddTool(201, u'设置输出目录', set_output_dir_bmp, u'设置输出目录')
        self.ToolBar.AddTool(202, u'设置打包证书', set_sign_file_bmp, u'设置打包证书')
        # self.ToolBar.AddTool(203, u'下载渠道SDK', down_sdk_bmp, u'下载渠道SDK')
        self.ToolBar.AddTool(204, u'帮助说明', tool_help_bmp, u'帮助说明')

        self.ToolBar.AddSeparator()  # 分割
        self.Bind(wx.EVT_MENU, self.on_click_tool, id=200, id2=204)
        self.tool_bar_listener = ToolBarEventListener(self.project_fun,self.folder_fun,self.set_cer_fun,self.history_channel_data,self.curreent_chose_channel_id)
        self.ToolBar.Realize()  # 提交工具栏设置

        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetFieldsCount(2)
        self.statusbar.SetStatusWidths([-7, -2])
        # self.statusbar.SetStatusText(u' 注意该工具仅供学习使用, 切勿用于商业用途, 违者必究!', 0)
        # self.statusbar.SetStatusText(u' 若有问题请联系：448774260@qq.com', 1)

        self.old_panel = self.channelPanel
        self.new_panel = None

        self.old_list_panel = self.resourcePanel
        self.new_list_panel = None

    def project_fun(self,xcode_proj_path,plist_path,target_name):
        self.history_channel_data['xcode_proj_path'] = xcode_proj_path
        self.history_channel_data['plist_path'] = plist_path
        self.history_channel_data['target_name'] = target_name
        self.update_channel_data()
    def set_cer_fun(self,profile_path,profile_type,cer_type):
        self.history_channel_data['profile_path'] = profile_path
        self.history_channel_data['profile_type'] = str(profile_type)
        self.history_channel_data['cer_type'] = str(cer_type)

        print('==当前渠道号 ' + self.curreent_chose_channel_id)
        if self.curreent_chose_channel_id != '':
            #保存-渠道打包证书
            temp_dic = {}
            temp_dic['profile_path'] = profile_path
            temp_dic['profile_type'] = str(profile_type)
            temp_dic['cer_type'] = str(cer_type)

            if self.curreent_chose_channel_id in self.history_channel_data.keys():
                channel_dic = self.history_channel_data[self.curreent_chose_channel_id]
                channel_dic['channel_cer'] = temp_dic
                self.history_channel_data[self.curreent_chose_channel_id] = channel_dic
            else:
                channel_cer_dic = {}
                channel_cer_dic['channel_cer'] = temp_dic
                self.history_channel_data[self.curreent_chose_channel_id] = channel_cer_dic


        self.update_channel_data()
    def folder_fun(self,ipa_out_dir):
        self.history_channel_data['folder_path'] = ipa_out_dir
        self.update_channel_data()

    # 选择渠道资源后，更新为对应的配置界面
    def up_data_ui(self, channel_name, channel_id, channel_version, channel_path):

        if channel_id != '':
            self.curreent_chose_channel_id = channel_id
        # # 将每次选择的SDK信息,写到配置文件中
        # dir_config = os.path.join('DIR_WorkSpace', 'DIR_UIConfig')
        # config_str = {}
        # if channel_path:
        #     config_str['channel_file_path'] = channel_path
        #     self.tool_bar_listener.write_config_data(dir_config, 'UI_CONFIG_PARAMS', config_str)

        if self.new_panel is not None:
            self.old_panel.Destroy()
            self.old_panel = self.new_panel

        self.new_panel = JChannelPanel(self.child_spWindow, self.windowFrame, self.up_data_ui,self.history_channel_data,self.save_channel_data_fun,self.chose_image_fun,self.curreent_chose_channel_id,
                                       channel_name, channel_version)  # 创建新的面板
        self.child_spWindow.ReplaceWindow(self.old_panel, self.new_panel)

        self.old_panel.Hide()

        # === 更新 渠道信息
        self.update_channel_data()

    '''=======  更新操作过的历史数据 ======'''
    def update_channel_data(self):
        #更新证书-ui的历史数据
        self.tool_bar_listener.update_channel_data(self.history_channel_data,self.curreent_chose_channel_id)
        self.down_panel.update_channel_data(self.history_channel_data,self.curreent_chose_channel_id)
        # print('======== 更新之后的渠道信息参数 =======')
        # print(self.history_channel_data)

    ''' 保存渠道参数 '''
    def save_channel_data_fun(self,channel_id,channel_param_info):
        self.curreent_chose_channel_id = channel_id
        temp_dic = {}
        temp_dic['channel_param'] = channel_param_info
        if self.curreent_chose_channel_id in self.history_channel_data.keys():
            channel_dic = self.history_channel_data[self.curreent_chose_channel_id]
            channel_dic['channel_param'] = channel_param_info
            self.history_channel_data[channel_id] = channel_dic
        else:
            self.history_channel_data[channel_id] = temp_dic

    ''' 保存渠道的图片信息 '''
    def chose_image_fun(self,channel_id,image_path,image_type):

        self.curreent_chose_channel_id = channel_id
        if image_type == 'icon_path':
            if self.curreent_chose_channel_id in self.history_channel_data.keys():
                channel_dic = self.history_channel_data[self.curreent_chose_channel_id]
                channel_dic['icon_path'] = image_path
                self.history_channel_data[channel_id] = channel_dic
            else:
                self.history_channel_data[channel_id]['icon_path'] = image_path

        elif image_type == 'icon_mark_path':
            if self.curreent_chose_channel_id in self.history_channel_data.keys():
                channel_dic = self.history_channel_data[self.curreent_chose_channel_id]
                channel_dic['icon_mark_path'] = image_path
                self.history_channel_data[channel_id] = channel_dic
            else:
                self.history_channel_data[channel_id]['icon_mark_path'] = image_path

        elif image_type == 'splash_image':
            if self.curreent_chose_channel_id in self.history_channel_data.keys():
                channel_dic = self.history_channel_data[self.curreent_chose_channel_id]
                channel_dic['splash_image'] = image_path
                self.history_channel_data[channel_id] = channel_dic
            else:
                self.history_channel_data[channel_id]['splash_image'] = image_path


    # 下载完成后，更新列表
    def up_data_list(self):

        if self.new_list_panel is not None:
            self.old_list_panel.Destroy()
            self.old_list_panel = self.new_list_panel

        self.new_list_panel = JChannelSDKListPanel(self.child_spWindow, self.windowFrame, self.up_data_ui)  # 创建新的面板
        self.child_spWindow.ReplaceWindow(self.old_list_panel, self.new_list_panel)

        self.old_list_panel.Hide()

    def on_erase_back(self, event):
        if self.first < 2 or self.flag:
            self.spWindow.SetSashPosition(0)
            self.child_spWindow.SetSashPosition(self.left)
            self.first = self.first + 1
        self.Refresh()

    # 为工具栏的图标添加事件处理
    def on_click_tool(self, event):
        event_id = event.GetId()
        if event_id == 200:
            self.tool_bar_listener.open_game_apk(self)

        elif event_id == 201:
            self.tool_bar_listener.choose_apk_output_dir(self)

        elif event_id == 202:
            self.tool_bar_listener.set_sign_info(self)

        elif event_id == 203:
            self.tool_bar_listener.down_sdk_resource(self, self.up_data_list)
#帮助按钮点击
        elif event_id == 204:
            import webbrowser
            webbrowser.open("https://github.com/a1713599261/ios-game-sdk")


# 程序运行入口
if __name__ == "__main__":
    app = wx.App()
    green_size = wx.DisplaySize()
    a = green_size[0]*0.7
    b = green_size[1]*0.85
    frame = GuiMainFrame((a, b))
    frame.Show()
    app.MainLoop()





